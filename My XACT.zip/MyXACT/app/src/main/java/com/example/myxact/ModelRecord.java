package com.example.myxact;

public class ModelRecord {

    //Variables
    String id, titulo, image, evento, descripcion, equipo, dob, planta,  addedTime, updatedTime;

    //Constructor

    public ModelRecord(String id, String titulo, String image, String evento, String descripcion, String equipo, String dob,
                       String planta, String addedTime, String updatedTime) {
        this.id = id;
        this.titulo = titulo;
        this.image = image;
        this.evento = evento;
        this.descripcion = descripcion;
        this.equipo = equipo;
        this.dob = dob;
        this.planta = planta;
        this.addedTime = addedTime;
        this.updatedTime = updatedTime;
    }

    //Getter y Setter

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setName(String titulo) {
        this.titulo = titulo;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getEvento() {
        return evento;
    }

    public void setBio(String evento) {
        this.evento = evento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getPlanta() {
        return planta;
    }

    public void setPlanta(String planta) {
        this.planta = planta;
    }

    public String getAddedTime() {
        return addedTime;
    }

    public void setAddedTime(String addedTime) {
        this.addedTime = addedTime;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }
}
