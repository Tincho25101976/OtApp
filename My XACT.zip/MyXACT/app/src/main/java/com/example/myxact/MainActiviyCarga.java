package com.example.myxact;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.getbase.floatingactionbutton.FloatingActionButton;

public class MainActiviyCarga extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activiy_carga);
    }

    public void Siguiente1 (View view) {
        Intent siguiente = new Intent(this, MainActivity.class);
        startActivity(siguiente);
    }
    public void Siguiente2 (View view) {
        Intent siguiente = new Intent(this, AgregarDialogoActivity.class);
        startActivity(siguiente);
    }

}
