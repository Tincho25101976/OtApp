package com.example.myxact;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class AgregarDialogoActivity extends AppCompatActivity {

    Spinner repe1, repe2, repe3, repe4, epp1, epp2, epp3, epp4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_dialogo);

        repe1 = (Spinner) findViewById(R.id.repe1);
        repe2 = (Spinner) findViewById(R.id.repe2);
        repe3 = (Spinner) findViewById(R.id.repe3);
        repe4 = (Spinner) findViewById(R.id.repe4);
        epp1 = (Spinner) findViewById(R.id.epp1);
        epp2 = (Spinner) findViewById(R.id.epp2);
        epp3 = (Spinner) findViewById(R.id.epp3);
        epp4 = (Spinner) findViewById(R.id.epp4);

        String[] repes1 = {"","Ajustan EPP", "Cambian de posicion", "Reorganizan trabajo", "Dejan trabajo", "Colocan bloqueos", "Cierran lugar de trabajo"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, repes1);
        repe1.setAdapter(adapter2);

        String[] repes2 = {"","Ajustan EPP", "Cambian de posicion", "Reorganizan trabajo", "Dejan trabajo", "Colocan bloqueos", "Cierran lugar de trabajo"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, repes2);
        repe2.setAdapter(adapter1);

        String[] repes3 = {"","Ajustan EPP", "Cambian de posicion", "Reorganizan trabajo", "Dejan trabajo", "Colocan bloqueos", "Cierran lugar de trabajo"};
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, repes3);
        repe3.setAdapter(adapter3);

        String[] repes4 = {"","Ajustan EPP", "Cambian de posicion", "Reorganizan trabajo", "Dejan trabajo", "Colocan bloqueos", "Cierran lugar de trabajo"};
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, repes4);
        repe4.setAdapter(adapter4);

        String[] epps1 = {"","Cabeza", "Ojos y cara", "Oidos", "Sistema repiratorio", "Brazos y manos", "Tronco", "Piernas y pie"};
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, epps1);
        epp1.setAdapter(adapter5);

        String[] epps2 = {"","Cabeza", "Ojos y cara", "Oidos", "Sistema repiratorio", "Brazos y manos", "Tronco", "Piernas y pie"};
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, epps2);
        epp2.setAdapter(adapter6);

        String[] epps3 = {"","Cabeza", "Ojos y cara", "Oidos", "Sistema repiratorio", "Brazos y manos", "Tronco", "Piernas y pie"};
        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, epps3);
        epp3.setAdapter(adapter7);

        String[] epps4 = {"","Cabeza", "Ojos y cara", "Oidos", "Sistema repiratorio", "Brazos y manos", "Tronco", "Piernas y pie"};
        ArrayAdapter<String> adapter8 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, epps4);
        epp4.setAdapter(adapter8);


    }
}